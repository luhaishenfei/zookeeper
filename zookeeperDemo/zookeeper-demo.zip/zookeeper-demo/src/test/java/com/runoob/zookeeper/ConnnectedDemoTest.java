package com.runoob.zookeeper;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple ConnnectedDemo.
 */
public class ConnnectedDemoTest
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
